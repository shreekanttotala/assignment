import React, { Component } from 'react';
import './FizzBuzz.css';

class FizzBuzz extends Component {
    constructor(props) {
      super(props);
        this.state = {
          start:0,
          inputValue:'',
            list: []
        };

        this.handleOnChange = this.handleOnChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.nextPage = this.nextPage.bind(this);
        this.previousPage = this.previousPage.bind(this);
    }

    shouldComponentUpdate() {
      console.log(this.state);
      return true;
    }
  handleOnChange(event) {
    console.log(event);
    let value = event?event.target.value:'';
    console.log(value);
   this.setState({inputValue:value});
  }

  handleSubmit() {
    let { inputValue } = this.state;
    let list = [];
    if(inputValue !== '') {
      for(let i=1;i<=inputValue;i++) {
        list.push(i);
      }
    }
    this.setState({list, inputValue:''});
    }

    nextPage() {
      let { start } = this.state;
      this.setState({start: start+5});
    }

    previousPage() {
      let { start } = this.state;
      this.setState({start: start-5});
    }


  render() {
    const { inputValue, list, start } = this.state;
    let itemlist = list.splice(start, 5);
    console.log(this.state);
    return (
      <div className="fizz-buzz">
        <input className="input" type="text" name="num" ref='inputText' value={inputValue} onChange={this.handleOnChange} />
        <input type="button" className="button" onClick={this.handleSubmit} value="Go" />
        <input type="button" className="button" onClick={this.previousPage} value="prev" />
        <input type="button" className="button" onClick={this.nextPage} value="next" />
        <div className="list">
          <ul>
            {list.length > 0 && list.map((item, index) =>
            <li key={"item-" + index}>
              {(item%3) === 0 && <span className="fizz">fizz </span>}
              {(item%5) === 0 && <span className="buzz">buzz</span>}
              {(item%3) !== 0 && (item%5) !== 0 && <span className="default">{item}</span>}
            </li>
            )}
          </ul>
        </div>
      </div>
    );
  }

}

export default FizzBuzz;
